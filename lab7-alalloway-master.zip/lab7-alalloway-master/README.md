# GIS5577 Lab 7

## Creating Web Mapping Services
Lab 7 is due 4/30/19 6pm

Web mapping has become a very common way on interacting with geospatial data on the web. This exercise involves creating a web map service that is based of an event layer. You must use ArcMap to follow the steps in the power points.

This is a simple assignment, please put some effort into creating your WMS.



