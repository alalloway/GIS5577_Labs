/* 
Lab 7
Creating Web Mapping Services
Web mapping has become a very common way on interacting with geospatial data on the web.
This exercise involves creating a web map service that is based of an event layer.

Name: Alysha Alloway
Grade:  25 / 25
Comments: Good work


*/


/*
1. Your assignment is to create a web mapping service. You may choose any dataset currently within your PostgreSQL database. You will need to use ArcGIS (Can't use ArcPro) connected to an existing PostgreSQL geospatial table. Always verify that both services (PostgreSQL and ArcServer) are up and running before you begin.
Make sure to add your initials at the end of the service.
*/

/*
Azure ArcServer
https://tgis3.uspatial.umn.edu/arcgis/manager/
usr = x500
pswd = x5000

XSEDE PostgreSQL Server
149.165.170.114 
usr = x500
pswd = ?
*/


-- 2. Make sure to provide the url of completed service.
---- URL: https://tgis3.uspatial.umn.edu/arcgis/rest/services/Lab7_AlyshaAlloway/MapServer

-- 3. Explain in your own words what a web map service is and it purpose.
---- A web map service is basically an image of data served to a server, that can then be accessed from the internet and consumed by other services. 
---- It is a static representation of the data that can be used to visualize the data in mapping platforms. 

-- 4. Explain the fundamental differences between a WMS (Web Mapping Service) and WCS (Web Coverage Service) / WFS (Web Feature Service)
---- A WMS is a static image of data, capable only of visualization, while a WFS and WCS actually provide the data and allow people consuming the WCS or WFS to interact with the data. 

-- 5. What is a Web Processing Service ?
---- A WPS provides geographic processing functions so users can access specific geoprocessing tools, like an overlay or clip, through the internet, by accessing its URL just like a WMS/WFS/WCS. 
---- Users can then consume these tools served through a WPS in their own environments. 