/*
Name: Alysha Alloway
Homework 5
The purpose this homework assigment is to develop expertise in processing spatial raster data with PostGIS.
You should look at the postgis raster cheat sheet to help you formulate your SQL statements.

Grade 20 /25
Comments: Code is good there were a few error here and there but you were on the right track. See my code for fixes.
*/


/* 
Here is the metadata for the GLC2000 dataset
Pixel Value GLC Global Class (according to LCCS terminology)
1.      Tree Cover, broadleaved, evergreen LCCS >15% tree cover, tree height >3 (Examples of sub-classes at regional level* : closed > 40% tree cove; open 15-40% tree cover)
2.      Tree Cover, broadleaved, deciduous, closed 
3.      Tree Cover, broadleaved, deciduous, open (open 15-40% tree cover)
4.      Tree Cover, needle-leaved, evergreen
5.      Tree Cover, needle-leaved, deciduous
6.      Tree Cover, mixed leaf type
7.      Tree Cover, regularly flooded, fresh  water (& brackish)
8.      Tree Cover, regularly flooded, saline water, (daily variation of water level)
9.      Mosaic: Tree cover / Other natural vegetation 
10.     Tree Cover, burnt 
11.     Shrub Cover, closed-open, evergreen (Examples of sub-classes at reg. level *: (i) sparse tree layer)
12.     Shrub Cover, closed-open, deciduous (Examples of sub-classes at reg. level *: (i) sparse tree layer)
13.     Herbaceous Cover, closed-open (Examples of sub-classes at regional level *: (i) natural, (ii) pasture, (iii) sparse trees or shrubs) 
14.     Sparse Herbaceous or sparse Shrub Cover
15.     Regularly flooded Shrub and/or Herbaceous Cover
16.     Cultivated and managed areas (Examples of sub-classes at reg. level *: (i) terrestrial; (ii) aquatic (=flooded during cultivation),  and under terrestrial:  (iii) tree crop & shrubs (perennial),  (iv) herbaceous crops (annual), non-irrigated, (v) herbaceous crops (annual), irrigated)    
17.     Mosaic: Cropland / Tree Cover / Other natural vegetation
18.     Mosaic: Cropland / Shrub or Grass Cover 
19.     Bare Areas
20.     Water Bodies (natural & artificial)
21.     Snow and Ice (natural & artificial)
22.     Artificial surfaces and associated areas

*/


/*
For questions 1-8 please use the raster dataset GLC2000
*/

-- Question 1, Write the SQL code that creates a histogram of the state of Minnesota. A histogram is each unique pixel type and total number of pixels.
-- Good unpacking, but this isn't giving you the correct answer use the ST_ValueCount function
WITH dataset as
(
SELECT (ST_ValueCount(ST_Clip(r.rast, p.geom),1,True)).*
FROM gis5577.us_states p 
INNER JOIN gis5577.glc2000 r ON ST_Intersects(r.rast, p.geom)
WHERE name = 'Minnesota'
)
SELECT value, sum(count) as total_pixels
FROM dataset
GROUP BY value 
ORDER BY value

-- Question 2, Write the SQL code that returns the most commmon pixel value for each county in Minnesota
------ I had a really hard time with this, this is definitely not correct. I think some type of use of ST_ValueCount would be more appropriate... but I got pretty lost.  
WITH dataset as
(
SELECT name, (ST_ValueCount(ST_Clip(r.rast, p.geom),1,True)).*
FROM us_counties p 
INNER JOIN glc2000 r ON ST_Intersects(r.rast, p.geom)
WHERE statefp::integer = 27
), county_results as
(
SELECT name, value, sum(count) as total_pixels
FROM dataset
GROUP BY name, value 
ORDER BY name, value
) 
SELECT name, max(total_pixels) as mode_category
FROM county_results
GROUP BY name
ORDER BY name

-- Question 3, Write the SQL code that returns the minimum and maximum value for each county in Minnesota.
-- Pretty close
SELECT p.name, (ST_SummaryStatsAgg(ST_Clip(r.rast, p.geom),1,True)).*
FROM gis5577.us_states p 
INNER JOIN gis5577.glc2000 r ON ST_Intersects(r.rast, p.geom)
-- Question 4, Rewrite query in Question 3 so that it uses a subquery or common table expression.

---- I guess I did this backwards but I'll write code below that does it without a subquery, since my original answer already has a subquery in it?

SELECT round((ST_SummaryStatsAgg(r.rast, 1, TRUE, 1)).max::numeric, 3) as county_max,
round((ST_SummaryStatsAgg(r.rast, 1, TRUE, 1)).min::numeric, 3) as county_min, 
c.name
FROM glc2000 as r
INNER JOIN us_counties as c ON ST_Intersects(r.rast, c.geom)
WHERE c.statefp = '27'
GROUP BY c.name;

-- Question 5, Write the SQL code that reclassifies Mosaic: Cropland / Shrub or Grass Cover (pixel value = 18 to pixel value 20)

ALTER TABLE glc2000 ADD COLUMN reclass_rast raster;
UPDATE glc2000 as r SET reclass_rast = ST_Reclass(r.rast,1,'18:20', '4BUI',0);


-- Question 6, Rewrite the query from question 5 to group the non-liveable places to a new pixel value 30. Then count the number of new pixels. Non-liveable places are water bodies and snow and ice.
----- water bodies = 20, snow & ice = 21

SELECT ST_ValueCount(ST_Reclass(ST_Clip(r.rast, p.geom),1,'20-21:30','8BUI',0))
FROM gis5577.us_states p 
INNER JOIN gis5577.glc2000 r ON ST_Intersects(r.rast, p.geom)

-- Question 7, Write the SQL code that reclassifies all trees (Example not the actual values pixel value = [3,4,5,6] ) to a new category forest. 
UPDATE glc2000 SET reclass_rast = ST_Reclass(rast,1,'1-10:40','8BUI',0);
SELECT r.rid,r.reclass_rast, ST_ValueCount(r.rast,1,40) as pixcount
FROM glc2000 as r;

-- Question 8, Write the SQL code that uses map algebra that multiplies all your pixel values by 5.

SELECT rast.rid,ST_MapAlgebra(rast, 1 , NULL, '[rast] * 5') as mult
FROM glc2000 as rast;