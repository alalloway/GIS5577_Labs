# GIS5577 Lab 5

Lab 4 is due 4/2/19 6pm

This lab is designed to help you learn how to use the PostGIS raster operators. Always ask questions in the discussion forum, you get participation points.