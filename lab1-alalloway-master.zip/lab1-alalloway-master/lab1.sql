/*
Name: Alysha
2/19/19
Grade 25/25
Comments
Code is good. Remember to start every statement on a separate line.
Don't forget to put an alias (AS) after a function otherwise it takes on the column name
*/

-- Select from the dataset the following states minnesota, alabama, wisconsin, illinois?
SELECT * 
FROM census_tracts_2000_diversity
WHERE state_name = 'Minnesota' OR state_name = 'Alabama' OR state_name= 'Wisconsin' OR state_name= 'Illinois'
-- WHERE state_name IN ('Minnesota', 'Alabama') #simpler

-- Which state has the most census tracts?
SELECT state_name, COUNT (census_tract_code) as total_num_tracts
FROM census_tracts_2000_diversity
GROUP BY state_name 
ORDER BY COUNT DESC
LIMIT 1

-- Which state has the largest population?
SELECT state_name, SUM (total)
FROM census_tracts_2000_diversity
GROUP BY state_name 
ORDER BY SUM DESC
LIMIT 1

-- Which state has the largest population of people over the age of 65?
SELECT state_name,
SUM (male_65_and_66_years+male_67_to_69_years+male_70_to_74_years+male_80_to_84_years+male_85_years_and_over+female_65_and_66_years+female_67_to_69_years+female_70_to_74_years+female_80_to_84_years+female_85_years_and_over) 
	 as total_over_65
FROM census_tracts_2000_diversity
GROUP BY state_name ORDER BY total_over_65 DESC
LIMIT 1

-- Which state has the largest population of people 17 and under?
-- Since the function is so long its appropriate to put it on a separate line
SELECT state_name,
SUM (male_under_5_years+male_5_to_9_years+male_10_to_14_years+male_15_to_17_years+female_under_5_years+female_5_to_9_years+female_10_to_14_years+female_15_to_17_years)
	 as total_under_17
FROM census_tracts_2000_diversity
GROUP BY state_name ORDER BY total_under_17 DESC
LIMIT 1

-- What are the top 10 states with the largest populations?
SELECT state_name, SUM (total) AS 
FROM census_tracts_2000_diversity
GROUP BY state_name ORDER BY SUM DESC
LIMIT 10

-- How many counties are in each state?
SELECT state_name,
COUNT (DISTINCT county_code)
FROM census_tracts_2000_diversity
GROUP BY state_name 

-- Which state has the largest population of american indians?
SELECT state_name,
SUM (american_indian_alone)
FROM census_tracts_2000_diversity
GROUP BY state_name ORDER BY SUM DESC
LIMIT 1

-- Which census tract has the largest proportion of male to women ratio?
-- Might want to return that information
SELECT census_tract_code, male/female AS
FROM census_tracts_2000_diversity
WHERE male !=0 AND female!=0
ORDER BY male/female DESC
LIMIT 1

-- Which states the top 10 census tracts with unequal ratios in?
SELECT census_tract_code, state_name, male/female AS
FROM census_tracts_2000_diversity
WHERE male !=0 AND female!=0
ORDER BY male/female DESC
LIMIT 10

-- Which census tracts have a majority minority population?
SELECT census_tract_code
FROM census_tracts_2000_diversity
WHERE white_alone/total < 0.5 AND total != 0
