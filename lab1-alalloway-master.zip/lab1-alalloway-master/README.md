# GIS5777_lab1
This repository contains the data and questions needed for your first homework assignment, lab 1.
This assignment is to be completed (committed) to github by 6pm on 1/30/18
