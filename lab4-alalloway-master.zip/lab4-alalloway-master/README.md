# GIS5777_lab4
lab4


Lab 4 is due 6/3/18 6pm

This lab is designed to help you learn the practical application of the PostGIS spatial operators. 
Always ask questions in the discussion forum, you get participation points.