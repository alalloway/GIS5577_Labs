/*
Name: Alysha Alloway
Homework 4

The purpose this homework assigment is to develop expertise in processing spatial data with PostGIS.
You should look at the postgis cheat sheet to help you formulate your SQL statements.

Grade  25/25

Comments: Code is good, just minor issues. I fixed a few statements and provided some suggestions.
*/



/*
Please load the mn_census_tracts_2010 for questions 1-6
*/

-- 1) Write the SQL query that will generate a single polygon of the state of Minnesota from the census tracts
SELECT state_name,
	 ST_Multi(ST_Union(t.geom)) AS MN_state
	 FROM mn_census_tracts_2010 AS t 
GROUP BY state_name;

-- 2) Write the SQL query that will report the spatial extent of the state of Minnesota
SELECT ST_Extent(mn_census_tracts_2010.geom) 
AS MN_extent 
FROM mn_census_tracts_2010;

/*You can use multiple statements or type in the values necessary for creating the polyline */
-- 3) Write the SQL query that will create a polyline that traverses the middle of the state.
CREATE TABLE MN_line AS
SELECT ST_SETSRID(ST_MakeLine(
ST_MakePoint(-97.239,(43.499+((49.384-43.499)/2))),
ST_MakePoint(-89.492,(43.499+((49.384-43.499)/2)))), 4326) AS polyline
);
-- 4) Write the SQL query that splits the state in half (based on your results from question 2) east to west and store it in a table.
--I don't think this is completely correct, since I'm missing a primary key, but I shared this code with many students in the class who were stuck (Whitney, Nic, maybe some more people)
--I tried altering the MN_half table to add a column and populate it with a primary key, but still couldn't view it in QGIS - what did I do wrong here?
CREATE TABLE MN_half6 AS
SELECT (ST_Dump(ST_Split(mn_census_tracts_2010.geom, mn_line.polyline))).* AS polygon
FROM mn_census_tracts_2010,mn_line

WITH state as 
(
1 as id, ST_Union(t.geom) AS geom
FROM mn_census_tracts_2010 AS t 
GROUP BY state_name
)
SELECT (ST_Dump(ST_Split(mn_census_tracts_2010.geom, m.polyline))).* AS polygon
FROM state 
INNER JOIN mn_line m on ST_Intersecst(state.geom, m.polyling)


-- 5) Write the SQL query that returns the census tracts that intersect with the polyline
SELECT census_tra AS ct
FROM mn_census_tracts_2010 AS c
INNER JOIN mn_line AS l
ON ST_Intersects(c.geom,l.polyline);

-- 6) Write the SQL query that returns the census tracts that do not intersect with the polyline. Please use 1 query with 1 or more Common Table Expressions or subqueries
SELECT census_tra AS ct
FROM mn_census_tracts_2010 AS c
INNER JOIN mn_line AS l
ON ST_Disjoint(c.geom,l.polyline);

/*
For questions 7-12 use the mn_counties and random-points files (load both datasets).
*/

-- 7) Write the SQL query that creates a view of centroids for MN counties call the view mn_county_centroids. Look at all the questions before creating the view to ensure you have all the information necessary.
CREATE VIEW MNcounty_centroids
AS SELECT mc.name, ST_Centroid(mc.geom) as geom --if you don't do this your fields names are ST_centroid
FROM mn_counties as mc

-- 8) Write the SQL query that identifies all random points that are within 5 kilometers of a county centroid
SELECT ST_DWithin(mcc.st_centroid::geography,rp.geom::geography,5000)
FROM MNcounty_centroids as mcc, random_points as rp;

-- 9) Write the SQL query that identifies all random points that are within 5 kilometers of the Anoka county centroid
SELECT ST_DWithin(mcc.st_centroid::geography,rp.geom::geography,5000)
FROM MNcounty_centroids as mcc, random_points as rp
WHERE mcc.name = 'Anoka'
-- 10) Are there any duplicate random points. If so write the SQL that identifies them.
SELECT *
FROM random_points as rp
WHERE ST_Intersects(rp.geom, rp.geom) AND rp.gid <> rp.gid
-- 11) Write the SQL query that identifies the number of duplicate points within each county.
SELECT count(rp.gid) as duplicates
FROM random_points as rp
WHERE ST_Intersects(rp.geom, rp.geom) AND rp.gid <> rp.gid

-- 12) If you were to delete a county in the mn_counties table, what would happen to the mn_county_centroids view
--The county would also drop from the mn_county_centroids view table