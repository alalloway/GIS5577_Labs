/*
Name: Alysha Alloway
Lab 2
2/27/19
Grade 24/25
Comments. Great code. REMEMBER your ALIASES

*/
/*
Homework 2
The purpose of this assignment is to teach you the basics of database management (CRUD) through a class exercise.
The purpose of this homework assignment is to work with PostgreSQL specific functions
1. aggregate functions https://www.postgresql.org/docs/10/functions-aggregate.html
2. string functions https://www.postgresql.org/docs/10/functions-string.html
3. date time functions https://www.postgresql.org/docs/10/functions-datetime.html

Learn to do analysis on tables
*/

/*
For questions 1-5 please use the iowa liquor sales table
Information about the Iowa liquor sales can be found at https://www.kaggle.com/residentmario/iowa-liquor-sales
*/
-- 1. On what date (invoice_date) was the most total sales of liquor?
SELECT invoice_date, sum(sale) as total_saales
FROM iowa_liquor_sales
GROUP BY invoice_date 
ORDER BY 2 DESC
LIMIT 1

-- 2. Which store (store_name) had the largest liquor sales?
SELECT store_name, sum(sale) as total_sales
FROM iowa_liquor_sales
GROUP BY store_name
ORDER BY sum(sale) DESC
LIMIT 1;

-- 3. Which county sold the least liquor?
SELECT county, sum(sale)
FROM iowa_liquor_sales
GROUP BY county 
ORDER BY sum(sale) ASC
LIMIT 1;

-- 4. Report for every category the min, max, and total sales?
SELECT category,category_name, min(sale),max(sale),sum(sale) --aliases
FROM iowa_liquor_sales
GROUP BY category,category_name;

-- 5. How much more liquor was sold in 2012 compared to 2016?
SELECT EXTRACT(YEAR FROM invoice_date) as sale_year,sum(sale)
FROM iowa_liquor_sales
WHERE EXTRACT(YEAR FROM invoice_date) = 2012 OR EXTRACT(YEAR FROM invoice_date) = 2016
GROUP BY sale_year;

-- Extra can you analyze question (2,3) by the month?
SELECT EXTRACT(MONTH FROM invoice_date) as sale_month, sum(sale)
FROM iowa_liquor_sales
GROUP BY sale_month
ORDER BY 2 --ASC for question 3 or DESC for question 2
LIMIT 1;

/*
For questions 6-10 please use the denver_crimes.csv
Information about the denver crimes spreadsheet can be found here. 
https://www.denvergov.org/opendata/dataset/city-and-county-of-denver-crime
*/

-- 6. Provide the data definition language (DDL) information used for creating the denver_crimes table
CREATE TABLE denver_crimes (
gid bigint, 
offense_id double precision,  
offense_code integer, 
offense_type_id text, 
offense_category_id text, 
reported_date date, 
precinct_id integer, 
neighborhood_name text, 
is_crim boolean, 
is_trafic boolean
);
-- 7. Provide the code you used for loading the data into the table. If you use INSERT VALUES 4 tuples is enough.
\COPY denver_crimes  FROM 'C:\work\lab2_alalloway\denver_crimes.csv' WITH CSV HEADER;

-- 8. Write the SQL statement used to group crimes by category, format string so that hyphens are spaces.
SELECT split_part(offense_category_id, '-', 1) ,count(1)
FROM denver_crimes
GROUP BY split_part(offense_category_id, '-', 1)
ORDER BY 1

-- 9. How many traffic violations were committed in August 2014.
SELECT EXTRACT(MONTH FROM reported_date) as crime_month,EXTRACT(YEAR FROM reported_date) as crime_year, COUNT(is_trafic) 
FROM denver_crimes
WHERE EXTRACT(MONTH FROM reported_date) = 08 AND  EXTRACT(YEAR FROM reported_date) = 2014 AND is_trafic = 't'
GROUP BY crime_month,crime_year,is_trafic;

-- 10. Report the top ten categories of crimes for the month of August 2014
SELECT EXTRACT(MONTH FROM reported_date) as crime_month,EXTRACT(YEAR FROM reported_date) as crime_year, offense_category_id 
FROM denver_crimes
WHERE EXTRACT(MONTH FROM reported_date) = 08 AND  EXTRACT(YEAR FROM reported_date) = 2014
GROUP BY offense_category_id,crime_month,crime_year
ORDER by COUNT(DISTINCT offense_category_id) DESC
LIMIT 10



