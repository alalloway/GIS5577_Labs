# GIS5577 Lab 2
Due February 19, by 6pm
This is the repository for homework #2


The purpose of this assignment is to teach you the basics of database management (Create Read Update Delete) (CRUD) through a class exercise. Students should load the datasets into their own database. 

The purpose of this homework assignment is to work with PostgreSQL specific functions

1. [aggregate functions](https://www.postgresql.org/docs/10/functions-aggregate.html)
1. [string functions](https://www.postgresql.org/docs/10/functions-string.html)
1. [date time functions](https://www.postgresql.org/docs/10/functions-datetime.html)


### Kaggle Liquor Sales
Information about the Iowa liquor sales can be found at [Kaggle](https://www.kaggle.com/residentmario/iowa-liquor-sales)
### Denver Crimes 2017
Information about the denver crimes spreadsheet can be found at the following
[link](https://www.denvergov.org/opendata/dataset/city-and-county-of-denver-crime)

