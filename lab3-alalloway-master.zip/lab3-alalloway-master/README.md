# GIS5577 Lab 3

Due February 26, by 6pm

The purpose of this assignment is to keep further developing the basic (CRUD) operations as well as JOINS. Students should load the datasets into their own database. The purpose of this homework assignment is to work with PostgreSQL specific functions


### Read
Mastering PostGIS Chapters 3 & 4


