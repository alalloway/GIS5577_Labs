/*
Name: Alysha
Homework 3

The purpose this homework assigment is to continue developing your knowledge in basic SQL.
Please look at the PSQL documentation to help understand how to develop the appropriate queries.

Grade  24/25

The code is great, good styles I made slight modifications

Comments
*/



-- Create and load the following csv mn_census_tracts and mn_county_pixel_values for these questions

-- 1) Write the select or create statement that results in a new table mn_tracts_2000 that contains the following fields by Total, White_alone Black_alone, American_Indian_alone, Asian_alone Hawaiian_PI_alone, SOR_alone)
CREATE TABLE mn_tracts_2000 
AS (SELECT Total, White_alone Black_alone, American_Indian_alone, Asian_alone Hawaiian_PI_alone, SOR_alone 
FROM mn_census_tracts_2000);

-- 2) Write the query neccessary for joining the census tracts to the county zonal statistics
SELECT * -- Remember to not always use *
FROM mn_census_tracts_2000
INNER JOIN mn_county_pixel_values
ON mn_census_tracts_2000.county_code = mn_county_pixel_values.county_code;

-- 3) What type of join is performed in question 2 and what are the join fields?

-- Inner join is performed because we want to select all the matching rows
--Join fields are county_code for both, in case county_name has spelling errors, etc. codes are a better choice

-- 4) If you use count of pixel as a proxy for area, which census tract has the most people per pixel
WITH county_population as
(
SELECT county_code, county_name, sum(total) as total_population
FROM mn_census_tracts_2000
GROUP BY county_code, county_name
), county_raster as
(
SELECT county_code, county_name, sum(pixel_count) as total_pixels
FROM mn_county_pixel_values 
GROUP BY county_code, county_name
)
SELECT cp.county_code, cp.county_name, total_population/total_pixels as population_per_pixel
FROM county_population cp 
INNER JOIN county_raster cr ON (cp.county_code = cr.county_code)
ORDER BY 3


-- 5) Write the select or create statement that results in a new table mn_county that contains the aggregates of the following fields by county (Total, one_race, White_alone Black_alone, American_Indian_alone, Asian_alone Hawaiian_PI_alone, SOR_alone)
CREATE TABLE mn_county
AS 
SELECT SUM(Total) AS total,
SUM(White_alone) AS White_alone,
SUM(Black_alone) AS Black_alone,
SUM(American_Indian_alone) AS American_Indian_alone,
SUM(Asian_alone) AS Asian_alone,
SUM(Hawaiian_PI_alone) AS Hawaiian_PI_alone,
SUM(SOR_alone) AS SOR_alone 
FROM mn_census_tracts_2000
GROUP BY mn_census_tracts_2000.county_code;

-- 6) Create a temporary table for question 5. 
CREATE TEMPORARY TABLE mn_county_temp
AS 
SELECT SUM(Total) AS total,
SUM(White_alone) AS White_alone,
SUM(Black_alone) AS Black_alone,
SUM(American_Indian_alone) AS American_Indian_alone,
SUM(Asian_alone) AS Asian_alone,
SUM(Hawaiian_PI_alone) AS Hawaiian_PI_alone,
SUM(SOR_alone) AS SOR_alone 
FROM mn_census_tracts_2000
GROUP BY mn_census_tracts_2000.county_code;
-- 7) What statement removes from the temporary table any records where the countyfp is 37, 19, or 53.

DELETE FROM mn_county_temp
WHERE mn_county_temp.County_Code IN (37,19,53);

-- 8) Create a view of question 5
CREATE VIEW mn_county_view 
AS 
SELECT SUM(Total) AS total,
SUM(White_alone) AS White_alone,
SUM(Black_alone) AS Black_alone,
SUM(American_Indian_alone) AS American_Indian_alone,
SUM(Asian_alone) AS Asian_alone,
SUM(Hawaiian_PI_alone) AS Hawaiian_PI_alone,
SUM(SOR_alone) AS SOR_alone 
FROM mn_census_tracts_2000
GROUP BY mn_census_tracts_2000.county_code;

/* EXTRA Understanding views
   1) Duplicate the mn_county table call it mn_county_test;
   2) Create a new view of the join in question 5
   2) Remove any records from the table mn_county_test where countyfp is 37, 19, or 53. 
   3) Query the new view to see how delete the data affecte the table
   4) INSERT INTO mn_county_test data for one county
   INSERT INTO mn_county_test
   SELECT
   FROM 
   WHERE countyfp = 37
*/
